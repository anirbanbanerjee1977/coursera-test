import argparse
from helper import get_input_args
from helper import setup_directories
from helper import setup_transforms
from helper import load_datasets
from helper import setup_dataloaders
from helper import buildNN
from helper import trainNN
from helper import testNN
from helper import saveCheckPoint
from helper import load_checkpoint

def main():
    #Get input arguments
    in_arg = get_input_args()
    
    #Setup Training,Validation & Test directories
    train_dir,valid_dir,test_dir = setup_directories(in_arg.data_dir)    
    
    #Define transforms for the training, validation, and testing sets
    training_transforms,validation_transforms,testing_transforms = setup_transforms()
    
    #Load the datasets with ImageFolder
    training_datasets,validation_datasets,testing_datasets =                load_datasets(train_dir,valid_dir,test_dir,training_transforms,validation_transforms,testing_transforms)
    
    #define the dataloaders
    training_loader,validation_loader,test_loader = setup_dataloaders(training_datasets,validation_datasets,testing_datasets)
    
    #build the network
    model = buildNN(in_arg.arch,in_arg.hidden_units)
    
    #train the network
    model,optimizer= trainNN(model,training_loader,validation_loader,in_arg.epochs,in_arg.learning_rate,in_arg.gpu)
    
    #test the accuracy of the network
    testNN(model,validation_loader,test_loader,in_arg.gpu)
    
    #save the checkpoint
    saveCheckPoint(model,training_datasets,in_arg.epochs,optimizer,in_arg.save_dir)
    
    #load the checkpoint
    #load_checkpoint('checkpoint.pth',model,optimizer)
    
    
    
# Call to main function to run the program
if __name__ == "__main__":
    main()
    
