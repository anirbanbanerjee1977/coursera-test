from helper import load_checkpoint
from helper import predict
from helper import sanitycheck
from helper import imshow
from helper import process_image
from helper import get_prediction_inputs

import torch
from PIL import Image

def main():
   #Get input arguments
    in_arg = get_prediction_inputs() 
    
    model = load_checkpoint(in_arg.checkpoint + '/checkpoint.pth',in_arg.learning_rate,in_arg.arch)
    if in_arg.gpu == 'gpu':
        prob,cls = predict(in_arg.path_to_image,model.cuda(),in_arg.top_k)
    else:
        prob,cls = predict(in_arg.path_to_image,model,in_arg.top_k)
        
    class_name = sanitycheck(cls,prob,in_arg.category_names)
    
    img = Image.open(in_arg.path_to_image)
    imshow(torch.tensor(process_image(img)),None,class_name)
    print('Finished Prediction')

# Call to main function to run the program
if __name__ == "__main__":
    main()
    